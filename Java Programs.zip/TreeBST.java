//Dominik Albiniak - 4
import java.util.Scanner;
public class Source {
    static Node root = null;
    static int length = 0;
    static  class Node {
    public int info;
    public Node left;
    public Node right;
    public Node (int info ) {
      this.info = info;
      left = null;
      right = null;
    }
    public Node () {
      info = 0;
      left = null;
      right = null;
    }
  }
     static  class Stack {
     public int maxSize;
     private Node[] stackArray;
     public int top;
     public Stack() {

        maxSize = length;
        stackArray = new Node[maxSize];
        top = -1;
     }
     public void push(Node j) {
        stackArray[++top] = j;
     }
     public Node pop() {
        return stackArray[top--];
     }
     public Node peek() {
        return stackArray[top];
     }
     public boolean empty() {
        return (top == -1);
     }
     public Node front() {
    	 return stackArray[0];
     }
  }
  static void insert (int x) {
	   if (search(x) != null) return;
       Node p, prev; // zmienne referencyjne
       Node s = new Node(x); // utwórz nowy węzeł
       s.left= null;
       s.right= null;
       if (root == null) root = s; // drzewo puste
       else {
         p = root; prev = null; // bieżący i poprzednik
         while ( p != null ) {
            prev = p;
            if ( x < p.info )
              p = p.left;
            else
              p = p.right;
          }
       // dowiąż nowy węzeł jako potomek prev
       if ( x < prev.info ) prev.left= s;
       else prev.right = s;
     }
     length++;
   }
  static Node search( int x ) {
       Node p = root;
       while ( p != null && x != p.info ) {
          if (x < p. info)
              p = p.left;
          else
              p = p.right;
       }
       return p;
   }
   static public Node minimum(Node Root){ //zwraca węzeł o minimalnej wartości klucza
         Node curr, last = null;
         curr = Root; // zaczynamy od korzenia
         while( curr != null) {
           last = curr; // zapamiętujemy węzeł
           curr = curr.left; // przechodzimy do lewego potomka
         }
         return last;
    }
    static public void printSuccessor(int x) {
		Node node = root;
		while (true) {
			if (x < node.info && node.left != null) {
				node = node.left;
			} else if (x > node.info && node.right != null) {
				node = node.right;
			} else if (x == node.info) {
				break;
			} else {
				System.out.println("BRAK");
				return;
			}
		}
		if (node.right != null) {
			node = node.right;
		} else {
			System.out.println("BRAK");
			return;
		}
		while (node.left != null) {
			node = node.left;
		}
		System.out.println(node.info);
	}
    public static void preorderIter() {
         if(root == null)
             return;
         Stack stack = new Stack();
         stack.push(root);

         while(!stack.empty()){

             Node n = stack.pop();
             System.out.print(n.info + " ");


             if(n.right != null){
                 stack.push(n.right);
             }
             if(n.left != null){
                 stack.push(n.left);
             }

         }
         System.out.println();

     }
     public static void inOrderIter() {

        if(root == null)
         return;

        Stack s = new Stack();
        Node currentNode=root;

        while(!s.empty() || currentNode!=null){

         if(currentNode!=null)
         {
          s.push(currentNode);
          currentNode=currentNode.left;
         }
         else
         {
          Node n=s.pop();
          System.out.print(n.info + " ");
          currentNode=n.right;
         }
        }
        System.out.println();
      }
      public static void postorderIter() {
          if( root == null ) return;

          Stack s = new Stack( );
          Node current = root;

          while( true ) {

              if( current != null ) {
                  if( current.right != null )
                   s.push( current.right );
                  s.push( current );
                  current = current.left;
                  continue;
            }

              if( s.empty( ) ) {
               System.out.println();
               return;
             }
              current = s.pop( );

              if( current.right != null && ! s.empty( ) && current.right == s.peek( ) ) {
                  s.pop( );
                  s.push( current );
                  current = current.right;
              } else {
                  System.out.print( current.info + " " );
                  current = null;
              }
          }
    }
      public static void levelOrderTraversal() {
    	  Node[] queue=new Node[length];
    	  int n = 0;
    	  queue[n++] = root;
    	  	while(n > 0) {
    	  		Node[] stack = new Node[length];
    	  		int m = 0;
    	  		int i = 0;
    	  		while (i < n) {
    	  			Node node = queue[i++];
    	  			System.out.print(node.info + " ");
    	  			if (node.left != null) {
    	  				stack[m++] = (node.left);
    	  			}
    	  			if (node.right != null) {
    	  				stack[m++] = (node.right);
    	  			}
    	  		}
    	  		n = m;
    	  		queue = stack;
    	  	}
    	  	System.out.println();
    	 }
      static void delete_node(int x) {
        Node node = root;
        Node tmp = null;
        boolean is_left = false;
        boolean endLoop = false;

        while (node != null && !endLoop) {
          if (x == node.info) {
            endLoop = true;
            tmp = root;
            node = null;
          } else if (x < node.info) {
            if (node.left != null && node.left.info == x) {
						 tmp = node.left;
					 	 is_left = true;
             endLoop = true;
					  } else {
					  	node = node.left;
					  }
          } else {
					if (node.right != null && node.right.info == x) {
						tmp = node.right;
            endLoop = true;
					} else {
						node = node.right;
					}
				 }
        }

        if (node != null) {
          if (tmp.left == null && tmp.right == null) {
            if (is_left == true) {
              node.left = null;
            } else {
              node.right = null;
            }
          } else if (tmp.left == null || tmp.right == null) {
            if (is_left == true) {
              node.left = tmp.left;
            } else {
              node.right = tmp.right;
            }
          } else {
            Node search = tmp.right;
  					Node parentSearch = null;
  					is_left = false;
            if (search.left != null) {
              parentSearch = search;
  						search = search.left;
  						is_left = true;
            }
  					while (search.left != null) {
  						parentSearch = search;
  						search = search.left;
  					}
  					tmp.info = search.info;
  					if (is_left == true) {
  						parentSearch.left = search.right;
  					} else {
  						tmp.right = search.right;
  					}
          }
        } else if (tmp == root && tmp != null) {
  				if (tmp.left == null && tmp.right == null) {
  					root = null;
  				} else if (tmp.left != null && tmp.right == null) {
  					root = tmp.left;
  				} else if (tmp.left == null && tmp.right != null) {
  					root = tmp.right;
  				} else {
  					Node search = tmp.right;
  					Node parentSearch = null;
  					is_left = false;
  					while (search.left != null) {
  						parentSearch = search;
  						search = search.left;
  						is_left = true;
  					}
  					tmp.info = search.info;
  					if (is_left == true) {
  						parentSearch.left = search.right;
  					} else {
  						tmp.right = search.right;
  					}
  				}
  			}
        length--;
      }
      static public void printParentKey(int childKey) {
			Node node = root;
			boolean checkLeft = true;
			while (true) {
				if (childKey < node.info) {
					if (node.left != null) {
						if (childKey == node.left.info) {
							System.out.println(node.info);
							break;
						} else {
							node = node.left;
						}
					} else {
						System.out.println("BRAK");
						break;
					}
				} else {
					if (node.right != null) {
						if (childKey == node.right.info) {
							System.out.println(node.info);
							break;
						} else {
							node = node.right;
						}
					} else {
						System.out.println("BRAK");
						break;
					}
				}
			}
		}
      static public void printPredecessor(int x) {
			Node node = root;
			while (true) {
				if (x < node.info && node.left != null) {
					node = node.left;
				} else if (x > node.info && node.right != null) {
					node = node.right;
				} else if (x == node.info) {
					break;
				} else {
					System.out.println("BRAK");
					return;
				}
			}
			if (node.left != null) {
				node = node.left;
			} else {
				System.out.println("BRAK");
				return;
			}
			while (node.right != null) {
				node = node.right;
			}
			System.out.println(node.info);
		}

      public static void main (String[] args) {
    	 int sos = 0;
        Scanner in = new Scanner(System.in);
        int zestaw = in.nextInt();
        //System.out.println(zestaw);
        while (zestaw > 0) {
          ++sos;
          System.out.println("ZESTAW: " + sos);
          int size = in.nextInt();
          //System.out.println(size);
          int[] arr = new int[size];
          in.nextLine();
          String treeStyle = in.nextLine();
          //System.out.println(treeStyle);
          //in.next();
          for (int i = 0; i < size; i++) {
            arr[i] = in.nextInt();
            //System.out.println(arr[i]);
          }
          if (treeStyle.contains("PREORDER")) {
            for (int i = 0 ; i < size; i++) {
              insert(arr[i]);
            }
          } else if (treeStyle.contains("POSTORDER")) {
            for (int i = size - 1; i >= 0; i--) {
              insert(arr[i]);
            }
          }
          int operations = in.nextInt();

          in.nextLine();
          while (operations > 0) {
            String choose = in.next();
            if (choose.contains("PREORDER")) {
                System.out.println("PREORDER:");
            	preorderIter();
            } else if (choose.contains("INORDER")) {
            	System.out.println("INORDER:");
                inOrderIter();
            } else if (choose.contains("POSTORDER")) {
            	System.out.println("POSTORDER:");
                postorderIter();
            } else if (choose.contains("LEVELORDER")) {
            	System.out.println("LEVELORDER:");
            	levelOrderTraversal();
            } else if (choose.contains("PARENT")) {
            	int childKey = in.nextInt();
				System.out.print("PARENT " + childKey + ": ");
				printParentKey(childKey);
            } else if (choose.contains("INSERT")) {
                int sea = in.nextInt();
                insert(sea);
            } else if (choose.contains("DELETE")) {
                int sea = in.nextInt();
                delete_node(sea);
            } else if (choose.contains("SUCCESSOR")) {
            	int x = in.nextInt();
				System.out.print("SUCCESSOR " + x + ": ");
				printSuccessor(x);
            } else if (choose.contains("PREDECESSOR")) {
            	int x = in.nextInt();
				System.out.print("PREDECESSOR " + x + ": ");
				printPredecessor(x);
            }
            operations--;
          }
          zestaw--;
          root = null;
        }
      }
}
/* TESTY

10
ZESTAW: 1
10
PREORDER
50 25 12 37 30 33 43 75 87 93
13
POSTORDER
LEVELORDER
PARENT 33
SUCCESSOR 50
PREDECESSOR 50
PARENT 50
DELETE 50
PARENT 50
POSTORDER
LEVELORDER
INSERT 35
INORDER
POSTORDER:
12 33 30 43 37 25 93 87 75 50
LEVELORDER:
50 25 75 12 37 87 30 43 93 33
PARENT 33: 30
SUCCESSOR 50: 75
PREDECESSOR 50: 43
PARENT 50: BRAK
PARENT 50: BRAK
POSTORDER:
12 33 30 43 37 25 93 87 75
LEVELORDER:
75 25 87 12 37 93 30 43 33
INORDER:
12 25 30 33 35 37 43 75 87 93
LEVELORDER
LEVELORDER:
75 25 87 12 37 93 30 43 33 35
ZESTAW: 2
1
PREORDER
666
15
INSERT 111
INSERT 222
INSERT 333
INSERT 444
INSERT 888
INSERT 777
INSERT 666
INSERT 555
LEVELORDER
LEVELORDER:
666 111 888 222 777 333 444 555
PARENT 111
PARENT 111: 666
PARENT 666
PARENT 666: BRAK
DELETE 666
LEVELORDER
LEVELORDER:
777 111 888 222 333 444 555
INSERT 776
LEVELORDER
LEVELORDER:
777 111 888 222 333 444 555 776
ZESTAW: 3
2
PREORDER
3 4
5
INSERT 1
INSERT 2
INSERT 5
DELETE 4
INORDER
INORDER:
1 2 3 5
ZESTAW: 4
4
POSTORDER
5 8 1 9
5
DELETE 5
DELETE 8
DELETE 1
DELETE 9
POSTORDER
POSTORDER:
ZESTAW: 5
40
PREORDER
1 6 9 2 7 3 5 45 12 20 77 99 65 21 45 87 0 16 23 98 32 78 98 90 50 60 46 29 30 31 41 59 86 74 75 44 78 63 77 66
3
INORDER
INORDER:
0 1 2 3 5 6 7 9 12 16 20 21 23 29 30 31 32 41 44 45 46 50 59 60 63 65 66 74 75 77 78 86 87 90 98 99
POSTORDER
POSTORDER:
0 5 3 2 7 16 31 30 29 44 41 32 23 21 20 12 46 59 63 60 50 66 75 74 65 86 78 90 98 87 99 77 45 9 6 1
LEVELORDER
LEVELORDER:
1 0 6 2 9 3 7 45 5 12 77 20 65 99 16 21 50 74 87 23 46 60 66 75 78 98 32 59 63 86 90 29 41 30 44 31
10
POSTORDER
8 4 6 5 1 2 9 0
7 8
4
INORDER
INORDER:
0 1 2 4 5 6 7 8 9
PARENT 6
PARENT 6: 5
SUCCESSOR 9
SUCCESSOR 9: BRAK
PREDECESSOR 1
PREDECESSOR 1: BRAK
ZESTAW: 2
8
PREORDER
8 4 6 5 1 2 9 0
6
PARENT 5
PARENT 5: 6
PARENT 0
PARENT 0: 1
SUCCESSOR 4
SUCCESSOR 4: 5
PREDECESSOR 4
PREDECESSOR 4: 2
LEVELORDER
LEVELORDER:
8 4 9 1 6 0 2 5
SUCCESSOR 2
SUCCESSOR 2: BRAK
ZESTAW: 3
3
POSTORDER
4 5 6
6
DELETE 4
DELETE 5
DELETE 6
INSERT 7
INSERT 1
LEVELORDER
LEVELORDER:
7 1

*/

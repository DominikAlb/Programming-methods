//Dominik Albiniak - 4
import java.util.Scanner;

public class Source {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int ile;
        ile = s.nextInt();
        s.nextLine();
        while (ile > 0) {
          String dane = s.nextLine();
          if (dane.charAt(0) == 'I') {//Infix
                String input = dane;
                String output = "";
                test theTrans = new test(input);
                output = theTrans.doTrans();
                if (theTrans.ile_pocz == theTrans.ile_kon)
                    System.out.println("ONP: " + output);
                else System.out.println("ONP: error");
          } else if (dane.charAt(0) == 'O') {//Postfix

                String tab[] = new String[256];

                for(int x = 0;x<dane.length();x++)
                    tab[x] = Character.toString(dane.charAt(x));

                int l = 0;

                for(int j = 0;j<tab.length;j++)
                    if(tab[j] != null)
                        l++;

                String wejscie[] = new String[l]; //tworze tablice
                for(int j = 0;j<l;j++)
                    wejscie[j] = tab[j];

                doINF(wejscie); //konwersja
          } else {
            System.out.println("error");
          }
          ile--;
        }

    }
    static int pobierzPriorytet(String znak)
    {
        if(znak.equals("="))
          return 1;
        else if(znak.equals("+") || znak.equals("-"))
            return 2;
        else if(znak.equals("*") || znak.equals("/") || znak.equals("%"))
            return 3;
        else if(znak.equals("^"))
            return 4;
        else if(znak.equals("~"))
            return 5;
        else if(znak.charAt(0) >= 'a' && znak.charAt(0) <= 'z')
            return 6;

        return 0; //0-blad reszrta od 1 do 6
    }
//pobierz wartosc, sprawdz warunki, sprawdz dokladnosc, zglos blad, dodaj nawiasy jesli true
    static void doINF(String[] wejscie)
    {
        stackArray stos = new stackArray(wejscie.length);                                            //stos ktory pojdzie na wyjscie
        stackArrayInt stosPriorytetow = new stackArrayInt(wejscie.length);                            //stos do obliczen

        String tmp = "";
        int liczbaOperandow = 0, liczbaOperatorow = 0;
        for(int j = 4;j<wejscie.length;j++)
        {
          //jezeli nie jest nawiasem
            if(!wejscie[j].equals("(") && !wejscie[j].equals(")"))
                if(wejscie[j].charAt(0) >= 'a' && wejscie[j].charAt(0) <= 'z')
                {//jezeli litera to daj na stos
                    stos.push(wejscie[j]);//element jest operandem, zwieksz liczbe operandow
                    stosPriorytetow.push(pobierzPriorytet(wejscie[j]));
                    liczbaOperandow++;
                }
                else if (wejscie[j].charAt(0) == '~' || wejscie[j].charAt(0) == '+' || wejscie[j].charAt(0) == '-' || wejscie[j].charAt(0) == '=' || wejscie[j].charAt(0) == '^' || wejscie[j].charAt(0) == '*' || wejscie[j].charAt(0) == '/' || wejscie[j].charAt(0) == '%' || wejscie[j].charAt(0) == '>' || wejscie[j].charAt(0) == '<')
                {//jezeli operator
                    tmp = "";

                    if(!wejscie[j].equals("~"))
                    {//jezeli nie ~ to zwieksz liczbe operatorow
                      //jezeli dany operator jest wiekszy lub rowny temu co na stosie to nawias
                        liczbaOperatorow++;

                        if(stosPriorytetow.top() <= pobierzPriorytet(wejscie[j]))
                            tmp = "(" + stos.pop() + ")";
                        else
                            tmp = stos.pop();
                      //przesun stos priorytetow
                        stosPriorytetow.pop();
                        //jezeli dany operator jest wiekszy od tego co na stosie teraz to  nawiasy
                        if(stosPriorytetow.top() < pobierzPriorytet(wejscie[j]))
                            tmp = "(" + stos.pop() + ")" + wejscie[j] + tmp;
                        else
                            tmp = stos.pop() + wejscie[j] + tmp;

                        stosPriorytetow.pop();
                    }
                    else
                    {//jezeli to ~
                        if(stosPriorytetow.top() <= pobierzPriorytet(wejscie[j]))
                            tmp = wejscie[j] + "(" + stos.pop() + ")";
                        else
                            tmp = wejscie[j] + stos.pop();

                        stosPriorytetow.pop();
                    }

                    stos.push(tmp);
                    stosPriorytetow.push(pobierzPriorytet(wejscie[j]));
                }
        }

        if(liczbaOperandow - 1 == liczbaOperatorow)
            System.out.println("INF: " + stos.pop());
        else
            System.out.println("INF: error");
    }
}
//klasy onp na inf
class stackArray
{
    private int maxSize;
    private String[] Elem;
    private int top;

    public stackArray(int size)
    {
        maxSize = size;

        Elem = new String[maxSize];
        top = maxSize;
    }

    public void push(String x)
    {
        if(!isFull())
            Elem[--top] = x;
    }

    public String pop()
    {
        if(isEmpty())
            return "";
        else
            return Elem[top++];
    }

    public String top()
    {
        if ( isEmpty() )
            return "";
        else
            return Elem[top];
    }

    public boolean isEmpty()
    {
        return (top == maxSize);
    }

    public boolean isFull()
    {
        return (top == 0);
    }
}
//tablica elementow
class stackArrayInt
{
    private int maxSize;//max dlugosc
    private int[] Elem;
    private int top;//dlugosc i gdzie jest ostatni element

    public stackArrayInt(int size)
    {
        maxSize = size;

        Elem = new int[maxSize];
        top = maxSize;
    }

    public void push(int x)
    {
        if(!isFull())
            Elem[--top] = x;
    }

    public int pop()
    {
        if(isEmpty())
            return 0;
        else
            return Elem[top++];
    }

    public int top()
    {
        if ( isEmpty() )
            return 0;
        else
            return Elem[top];
    }

    public boolean isEmpty()
    {
        return (top == maxSize);
    }

    public boolean isFull()
    {
        return (top == 0);
    }
}
//clasy z inf na onp
class test {
   private Stack theStack;
   private String input;
   private String output = "";//dla lewej strony
   private String outout = "";//dla prawej strony
   int ile_pocz = 0;// na (
   int ile_kon = 0;// na )
   public test(String in) {
      input = in;
      int stackSize = input.length();
      theStack = new Stack(stackSize);
   }
   public String doTrans() {
     String rowna = "";
     int op = 0;
     int po = 0;
     boolean wasEqualAndSomething = false;
      for (int j = 4; j < input.length(); j++) {
         char ch = input.charAt(j);
         char prev;
         if (j > 0) {
            prev = input.charAt(j - 1);
         } else {
            prev = '.';
         }
         if (prev == ')' && ch >= 'a' && ch <= 'z') {
           output = "error";
           return output;
         }
         if (prev == '(' && ch == ')') {
           output = "error";
           return output;
         }
         if (prev == '<' || prev == '>' || prev == '*' || prev == '%' || prev == '/' || prev == '-' || prev == '+' || prev == '~')
            if (ch == '<' || ch == '>' || ch == '*' || ch == '%' || ch == '/' || ch == '-' || ch == '+') {
              output = "error";
              return output;
            } // pobiera wartosc i sprawdza zgodnosc
         switch (ch) {
            case '=':
                if (prev == '=') {
                  output = "error";
                  return output;
                }
                op++;
                rowna += ch;
                if (wasEqualAndSomething) {
                  output = "error";
                  return output;
                }
                break;
            case '<':
            case '>':
                op++;
                wasEqualAndSomething = true;
                gotOper(ch, 1);
                break;
            case '+':
            case '-':
               wasEqualAndSomething = true;
               op++;
               gotOper(ch, 2);
               break;
            case '*':
            case '/':
            case '%':
               op++;
               wasEqualAndSomething = true;
               gotOper(ch, 3);
               break;
            case '^':
                op++;
                wasEqualAndSomething = true;
                gotOperNext(ch, 4);
                break;
            case '~':
                gotOperNext(ch, 5);
                wasEqualAndSomething = true;
                break;
            case '(':
               ile_pocz++;
               theStack.push(ch);
               break;
            case ')':
               ile_kon++;
               gotParen(ch);
               if (output == "?") {
                 output = "error";
                 return output;
               }
               break;
            default:
               if ((ch >= 'a' && ch <= 'z')) {
                   output = output + ch;
                   output += outout;
                   outout = "";
                   po++;
               }
                  break;
         }
      }//jezeli koniec
      while (!theStack.isEmpty()) {
         output = output + theStack.pop();
      }
      if (po - 1 != op) {
        output = "error";
        return output;
      }
      output += rowna;
      return output;
   }//lewa strona tzn. - + / * % < >
   public void gotOper(char opThis, int prec1) {
      while (!theStack.isEmpty()) {
         char opTop = theStack.pop();
         if (opTop == '(') {
            theStack.push(opTop);
            break;
         } else {
            int prec2 = -1;
            if (opTop == '+' || opTop == '-') {
                prec2 = 2;
            } else if (opTop == '=') {
                prec2 = 0;
            } else if (opTop == '<' || opTop == '>') {
                prec2 = 1;
            } else if (opTop == '*' || opTop == '/' || opTop == '%') {
                prec2 = 3;
            } else if (opTop == '^') {
                prec2 = 4;
            } else if (opTop == '~') {
                prec2 = 5;
            }
            if (prec2 < prec1) {//<=?
               theStack.push(opTop);
               break;
            }
            else output = output + opTop;
         }
      }
      theStack.push(opThis);
   }//prawa strona tzn ^ = ~
   public void gotOperNext(char opThis, int prec1) {
      while (!theStack.isEmpty()) {
         char opTop = theStack.pop();
         if (opTop == '(') {
            theStack.push(opTop);
            break;
         } else {
            int prec2 = -1;
            if (opTop == '+' || opTop == '-') {
                prec2 = 2;
            } else if (opTop == '=') {
                prec2 = 0;
            } else if (opTop == '<' || opTop == '>') {
                prec2 = 1;
            } else if (opTop == '*' || opTop == '/' || opTop == '%') {
                prec2 = 3;
            } else if (opTop == '^') {
                prec2 = 4;
            } else if (opTop == '~') {
                prec2 = 5;
            }
            if (prec2 < prec1) {//<=?
               theStack.push(opTop);
               break;
            }
            else outout = outout + opTop;
         }
      }
      theStack.push(opThis);
   }// sprawdz nawiasy, jezeli nie znajdziesz konca zglos blad
   public void gotParen(char ch) {
     char chx = 'Q';
      while (!theStack.isEmpty()) {
         chx = theStack.pop();
         if (chx == '(')
         break;
         else output = output + chx;
      }
      if (chx != '(')
        output = "?";
   }
   //tablica elementow
   class Stack {
      private int maxSize;
      private char[] stackArray;
      private int top;

      public Stack(int max) {
         maxSize = max;
         stackArray = new char[maxSize];
         top = -1;
      }
      public void push(char j) {
         stackArray[++top] = j;
      }
      public char pop() {
         return stackArray[top--];
      }
      public char peek() {
         return stackArray[top];
      }
      public boolean isEmpty() {
         return (top == -1);
      }
   }
}
//        Testy:
/*
INF: (a+b)c+
ONP: error

INF: a+()b
ONP: error

a+d+e-d
error

INF: a+d+e-d
ONP: ad+e+d-

INF: a^b^c
ONP: abc^^

INF: a=b=c=d+e
ONP: abcde+===

ONP: ab+()
INF: a+b

INF: (a+b*(c-d^e)^f%w)+(a+b+c-(a+b-(~c)))
ONP: abcde^-f^*w%+ab+c+ab+c~--+

ONP: abcde^-f^*w%+ab+c+ab+c~--+
INF: a+b*(c-d^e)^f%w+(a+b+c-(a+b-~c))

ONP: ab+
INF: a+b

ONP: ab+-
INF: error

ONP: xa~=
INF: x=~a

ONP: abcd***
INF: a*(b*(c*d))

INF: a*b*c*d
ONP: ab*c*d*

ONP: ab*c*d*
INF: a*b*c*d

INF: x=a+~~~~b-c
ONP: xab~~~~+c-=

ONP: xab~~~~+c-=
INF: x=a+~(~(~(~b)))-c

ONP: c++
INF: error

INF: a%b-c%d
ONP: ab%cd%-

ONP: ab%cd%-
INF: a%b-c%d
*/

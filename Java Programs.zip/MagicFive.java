//Dominik Albiniak - 4
//program w Javie znajdujący k-ty co do wielkości element tablicy w porządku
//niemalejącym, licząc od najmniejszego (k = 1 - element najmniejszy).
import java.util.Scanner;
class Source {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		while(n>0){
			int m = in.nextInt();
			int[] tab = new int[m];
			for (int i = 0 ; i < m; i++) {
				tab[i] = in.nextInt();
			}
			int j = in.nextInt();
			int bat;
			for (int i = 0; i < j; i++) {
				bat= in.nextInt();
				if (bat > m || bat < 1)
						System.out.println(bat + " brak");
				else {
					if(m < 5) {
						sort(tab, 0 , tab.length);
						System.out.println(bat + " " + tab[bat - 1]);
					} else System.out.println(bat + " " + Select2(tab,tab.length,  bat));
				}
			}
			n--;
		}
	}
	public static int Select2 (int tab[],int length,  int number) {
		if(length < 5) {
			sort(tab, 0 , length);
			if (number > 0)
				return tab[number - 1];
			else return tab[number];
		}
		int i = length;
		int liczba = 0;
		int[] Q;
		if ((i) % 5 == 0) Q = new int[i/5];
		else Q = new int[i/5 + 1];
		while(liczba + 5 <= i) {
			sort(tab, liczba, liczba + 5);
			liczba += 5;
		}
		if (liczba != i)
			sort(tab, liczba , i);
		liczba = 0;
		int j = 0;
		while (liczba + 5 <= i) {
			Q[j++] = mediana(tab, liczba, liczba + 5);
			liczba += 5;
		}
		if (liczba != i)
			Q[j] = mediana(tab, liczba, i);
		int M = Select2(Q,Q.length,  (Q.length)/2);
		int[] S1, S2, S3;
		S1 = new int[i];
		S2 = new int[i];
		S3 = new int[i];
		int x, y, z;
		x = y = z = 0;
		for (int n = 0; n < i; n++) {
			 if (tab[n] < M) {
					 S1[x++] = tab[n];
			 } else if (tab[n] == M) {
					 S2[y++] = tab[n];
			 } else if (tab[n] > M) {
					 S3[z++] = tab[n];
			 }
		}
		if (number <= x ){
			return Select2 (S1, x, number);
		}
		if (number <= x + y) return M;
		return Select2 (S3,z, number - x - y);
	}
	public static int mediana(int[] tablica, int left, int right) {
      int mediana = 0;
      int srednia = 0;
      if ((left + right) % 2 == 0 && right - left > 1) {
          srednia = tablica[(left + right)/2 - 1] + tablica[((left + right)/2)];
          mediana = srednia/2;
      }
      else mediana = tablica[(left + right)/2];
      return mediana;
  }
	public static void sort(int arr[], int left, int right) {
        for (int i=left + 1; i<right; ++i)
        {
            int key = arr[i];
            int j = i-1;
            while (j>=left && arr[j] > key)
            {
                arr[j+1] = arr[j];
                j = j-1;
            }
            arr[j+1] = key;
        }
    }
}
/* TESTY:
10
6
1 2 3 4 5 6
3
4 5 6
4 4
5 5
6 6
20
7 5 6 9 8 7 5 8 0 0 0 0 0 8 6 4 8 9 7 6
5
-1 0 10 16 19
-1 brak
0 brak
10 6
16 8
19 9
10
8 9 7 6 5 8 7 6 6 6
3 6 10 0
6 7
10 9
0 brak
7
7 8 6 5 8 7 6
4
-1 -10 0 29
-1 brak
-10 brak
0 brak
29 brak
10
6 7 8 5 6 4 5 6 7 8
3 3 4 3
3 5
4 6
3 5
5
1 1 1 1 1
3
1 3 5
1 1
3 1
5 1
3
0 9 0
2
1 2
1 0
2 0
5
7 6 8 9 0
6
1 2 3 4 5 6
1 0
2 6
3 7
4 8
5 9
6 brak
6
7 6 8 7 6 5
3
4 5 6
4 7
5 7
6 8
4
3 5 6 7
3
45 5 5
45 brak
5 brak
5 brak

*/

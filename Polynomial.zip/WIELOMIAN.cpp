// Author: Dominik Albiniak
/**
This program create polynomial with operations:
    + - = += -= * / /= *= % %= and bool operation
    like > < >= <= ==
    and more
    first variable is size and parameters x0 x1 x2...
    for example WIELOMIAN W(3, 2, 3, 4, 5)
    is 2x0 + 3x1 + 4x2 + 5x3
                                                    **/
using namespace std;
int nwd(int a,int b) {
        if (b == 0) {
            if (a != 0) {
                return a;
            } else {
                return 1;
            }
        } else {
            nwd(b, a%b);
        }
}
int NWD(int A[], int n) {
    int C[n];
    for (int i = 0;i < n;i++) {
        if (A[i] < 0)
            C[i] = -A[i];
        else C[i] = A[i];
    }
    if (n == 1) {
        if(C[0] > 0)
            return C[0];
        else
            return 1;
    }
        int i = n - 2;
        while(i >= 0) {
            C[i] = nwd(C[i + 1], C[i]);
            i--;
        }
        i++;
        if(C[i] > 0)
            return C[i];
        else
            return 1;
}


class WIELOMIAN {
public:
    WIELOMIAN() {
        size = 1;
        wielomian = new int[1];
        wielomian[0] = 0;
    }
    WIELOMIAN(int* tab, int s, string a){

        for(int i = s-1; i >= 0; --i){
            if(tab[i] == 0) --s;
            else break;
        }

        if(s <= 0) s = 1;

        size = s;
        wielomian = new int[size];
        for(int i = 0; i < size; ++i){
            wielomian[i] = tab[i];
        }

        while(wielomian[size - 1] == 0) size--;
        int value = NWD(wielomian, size);
        for (int i = 0; i < size; i++) wielomian[i] /= value;
    }
    WIELOMIAN(int size, ...) {
        size++;
        this->size = size;

        wielomian = new int[this->size];

        va_list arg;

        va_start(arg, size);

        for (int i = 0;i < this->size ;i++)
            wielomian[i] = va_arg(arg, int);

        va_end(arg);
        while(wielomian[size - 1] == 0) size--;
        int value = NWD(wielomian, size);
        for (int i = 0; i < size; i++) wielomian[i] /= value;
    }
    WIELOMIAN(int* wiel, int size, int to) {
        this -> size = size;
        wielomian = new int[size];
        for (int i = 0;i < to; i++) {
            wielomian[i] = wiel[i];
        }
        for (int i = to ; i < size; i++) {
            wielomian[i] = 0;
        }
    }
    ~WIELOMIAN(){delete[] wielomian;
    }
    WIELOMIAN(const WIELOMIAN & wiel) {
        this->size = wiel.size;
        this->wielomian = new int[wiel.size];
        for (int i = 0; i < wiel.size; i++) {
            this->wielomian[i] = wiel.wielomian[i];
        }
    }
    //metody:
    WIELOMIAN& operator=(WIELOMIAN w1) {
        this->size = w1.size;
        delete[] this->wielomian;
        this->wielomian = new int[size + 1];
        for (int i = 0;i < this->size;i++)
            this->wielomian[i] = w1.wielomian[i];

        return *this;
    }
    WIELOMIAN operator-() {
        WIELOMIAN W(wielomian, size, size);
        for (int i = 0 ; i < size ; i++) {
            W.wielomian[i] = -wielomian[i];
        }
        return W;
    }
    WIELOMIAN operator+(WIELOMIAN wiel) {
        if (size >= wiel.size) {
            int tab[size];
            for (int i = 0;i < size; i++) {
                tab[i] = this->wielomian[i];
            }
            WIELOMIAN W;
            for (int i = 0;i < wiel.size; i++) {
                tab[i] += wiel.wielomian[i];
            }
            delete[] W.wielomian;
            W.wielomian = new int[this->size];
            W.size = this->size;
            for (int i = 0;i < this->size; i++) {
                W.wielomian[i] = tab[i];
            }
            while(W.size - 1 >= 0 && W.wielomian[W.size - 1] == 0) W.size--;
            int value = NWD(W.wielomian, W.size);
            for (int i = 0; i < W.size; i++) W.wielomian[i] /= value;
            return W;
        } else {
            int tab[wiel.size];
            for (int i = 0;i < wiel.size; i++) {
                tab[i] = wiel.wielomian[i];
            }
            WIELOMIAN W;
            for (int i = 0;i < this->size; i++) {
                tab[i] += this->wielomian[i];
            }
            delete[] W.wielomian;
            W.wielomian = new int[wiel.size];
            W.size = wiel.size;
            for (int i = 0;i < wiel.size; i++) {
                W.wielomian[i] = tab[i];
            }
            while(W.size - 1 >= 0 && W.wielomian[W.size - 1] == 0) W.size--;
            int value = NWD(W.wielomian, W.size);
            for (int i = 0; i < W.size; i++) W.wielomian[i] /= value;
            return W;
        }
    }
    WIELOMIAN operator-(WIELOMIAN wiel) {
        int* tab;
        int newSize;
        int less;
        if(size > wiel.size) {
            newSize = size;
            less = wiel.size;
            tab = new int[newSize];
            for(int i = 0; i < size; ++i) tab[i] = wielomian[i];
        } else {
            newSize = wiel.size;
            less = size;
            tab = new int[newSize];
            for(int i = 0; i < wiel.size; ++i) tab[i] = -wiel.wielomian[i];
        }

        for(int i = 0; i < less; ++i){
            tab[i] = wielomian[i] - wiel.wielomian[i];
        }

        WIELOMIAN W(tab, newSize, newSize);

        while(W.size - 1 >= 0 && W.wielomian[W.size - 1] == 0) W.size--;
        int value = NWD(W.wielomian, W.size);
        for (int i = 0; i < W.size; i++) W.wielomian[i] /= value;


        return W;

    }
    WIELOMIAN operator*(WIELOMIAN wiel) {
        WIELOMIAN W(wielomian, size + wiel.size - 1, size);
        for (int i = 0; i < size + wiel.size - 1; i++) {
            W.wielomian[i] = 0;
        }
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < wiel.size; j++) {
                W.wielomian[i + j] += wiel.wielomian[j] * wielomian[i];
            }
        }
        while(W.wielomian[W.size - 1] == 0) W.size--;
        int value = NWD(W.wielomian, W.size);
        for (int i = 0; i < W.size; i++) W.wielomian[i] /= value;
        return W;
    }
    WIELOMIAN operator/ (WIELOMIAN wiel) {
        if (size - wiel.size + 1 <= 0) {
            WIELOMIAN W(0, 0);
            return W;
        }

        //------------------
        int licznikThis[size];
        int mianownikThis[size];

        int licznikWiel[wiel.size];
        int mianownikWiel[wiel.size];

        for (int i = 0; i < size; i++) {
            licznikThis[i] = wielomian[i];
            mianownikThis[i] = 1;
        }
        if (size - wiel.size + 1 <= 0)
            return *this;
        int divide, rightN, divideN;

        WIELOMIAN left(this->wielomian, this->size, "a");
        WIELOMIAN right(wiel.wielomian, wiel.size, "a");
        int newSize = left.size - right.size + 1;
        int *zer = new int[newSize];
        for (int i = 0; i < newSize; ++i) zer[i] = 1;

        WIELOMIAN result(zer, newSize, "a");

        int* rightDiv = new int[right.size];
        int* leftDiv = new int[left.size];
        for(int i = 0; i < left.size; i++) leftDiv[i] = 1;
        int* resultDiv = new int[result.size];
        for(int i = 0; i < result.size; i++) resultDiv[i] = 1;
        int n = newSize - 1;
        int sizeLeft = left.size - 1;
        int sizeRight = right.size - 1;
        //------------------


        while(n >= 0) {
            newSize--;
            right = wiel;
            for(int i = 0; i < right.size; i++) rightDiv[i] = 1;

            rightN = left.wielomian[left.size - 1];
            divideN = right.wielomian[right.size - 1] * leftDiv[left.size - 1];
            divide = nwd(rightN, divideN);
            rightN /= divide;
            divideN /= divide;
            result.wielomian[newSize] = rightN;
            resultDiv[newSize] = divideN;

            for (int i = 0; i < right.size; i++) {

                right.wielomian[i] *= rightN;
                for (int k = 0 ;k < left.size; k++);
                rightDiv[i] *= divideN;
                divide = nwd(right.wielomian[i], rightDiv[i]);
                right.wielomian[i] /= divide;
                rightDiv[i] /= divide;
            }

            for (int i = 0; i < right.size; i++) {

                rightN = leftDiv[left.size - 1 - i];
                divideN = rightDiv[right.size - 1 - i];
                right.wielomian[right.size - 1 - i] *= rightN;
                rightDiv[right.size - 1 - i] *= rightN;
                left.wielomian[left.size - 1 - i] *= divideN;
                leftDiv[left.size - 1 - i] *= divideN;

                left.wielomian[left.size - 1 - i] -= right.wielomian[right.size - 1 - i];
                divide = nwd(left.wielomian[left.size - 1 - i], leftDiv[left.size - 1 - i]);
                left.wielomian[left.size - 1 - i] = left.wielomian[left.size - 1 - i] / divide;
                leftDiv[left.size - 1 - i] = leftDiv[left.size - 1 - i] / divide;
            }
            left.size--;
            n--;
        }

        int mianownik = resultDiv[0];
        if(mianownik < 0) mianownik = -mianownik;
        for(int i = 1; i < result.size; i++) {
            int a = resultDiv[i];
            if(a < 0) a = -a;

            if(a > mianownik) {
                mianownik = a;
            }
        }

        for(int i = 0; i < result.size; i++) {
            resultDiv[i] = mianownik / resultDiv[i];
            result.wielomian[i] *= resultDiv[i];
        }


        result.shortW();
        return result;
    }

    WIELOMIAN operator% (WIELOMIAN wiel) {
        //------------------
        if (size - wiel.size + 1 <= 0)
            return *this;

        int licznikThis[size];
        int mianownikThis[size];

        int licznikWiel[wiel.size];
        int mianownikWiel[wiel.size];

        for (int i = 0; i < size; i++) {
            licznikThis[i] = wielomian[i];
            mianownikThis[i] = 1;
        }
        int divide, rightN, divideN;

        WIELOMIAN left(this->wielomian, this->size, "a");
        WIELOMIAN right(wiel.wielomian, wiel.size, "a");
        int newSize = left.size - right.size + 1;
        int *zer = new int[newSize];
        for (int i = 0; i < newSize; ++i) zer[i] = 1;

        WIELOMIAN result(zer, newSize, "a");

        int* rightDiv = new int[right.size];
        int* leftDiv = new int[left.size];
        for(int i = 0; i < left.size; i++) leftDiv[i] = 1;
        int* resultDiv = new int[result.size];
        for(int i = 0; i < result.size; i++) resultDiv[i] = 1;
        int n = newSize - 1;
        int sizeLeft = left.size - 1;
        int sizeRight = right.size - 1;
        //------------------


        while(n >= 0) {
            newSize--;
            right = wiel;
            for(int i = 0; i < right.size; i++) rightDiv[i] = 1;

            rightN = left.wielomian[left.size - 1];
            divideN = right.wielomian[right.size - 1] * leftDiv[left.size - 1];
            divide = nwd(rightN, divideN);
            rightN /= divide;
            divideN /= divide;
            result.wielomian[newSize] = rightN;
            resultDiv[newSize] = divideN;

            for (int i = 0; i < right.size; i++) {

                right.wielomian[i] *= rightN;
                rightDiv[i] *= divideN;
                for (int k = 0 ;k < left.size; k++);
                divide = nwd(right.wielomian[i], rightDiv[i]);
                right.wielomian[i] /= divide;
                rightDiv[i] /= divide;
            }

            for (int i = 0; i < right.size; i++) {

                rightN = leftDiv[left.size - 1 - i];
                divideN = rightDiv[right.size - 1 - i];
                right.wielomian[right.size - 1 - i] *= rightN;
                rightDiv[right.size - 1 - i] *= rightN;
                left.wielomian[left.size - 1 - i] *= divideN;
                leftDiv[left.size - 1 - i] *= divideN;

                left.wielomian[left.size - 1 - i] -= right.wielomian[right.size - 1 - i];
                divide = nwd(left.wielomian[left.size - 1 - i], leftDiv[left.size - 1 - i]);
                left.wielomian[left.size - 1 - i] = left.wielomian[left.size - 1 - i] / divide;
                leftDiv[left.size - 1 - i] = leftDiv[left.size - 1 - i] / divide;

            }
            left.size--;
            n--;
        }

        int mianownik = leftDiv[0];
        if(mianownik < 0) mianownik = -mianownik;
        for(int i = 1; i < left.size; i++) {
            int a = leftDiv[i];
            if(a < 0) a = -a;

            if(a > mianownik) {
                mianownik = a;
            }
        }
        for(int i = 0; i < left.size; i++) {
            leftDiv[i] = mianownik / leftDiv[i];
            left.wielomian[i] *= leftDiv[i];
        }
        WIELOMIAN W(left.wielomian, this->size, "");
        return W;
    }
    WIELOMIAN operator<<(int ile) {
        if (ile == 0) {
            WIELOMIAN W(wielomian, size, size);
            return W;
        }
        if (ile < 0) {
            WIELOMIAN Q(0 , 0);
            return Q;
        }
        WIELOMIAN W(wielomian, size + ile, 0);
        for (int i = 0; i < size ; i++) {
            W.wielomian[i + ile] = (int)(wielomian[i] * ile);
        }
        return W;
    }
    void shortW(){
        int res = NWD(wielomian, size);
        if(res == 0) return;
        for(int i = 0; i < size; ++i){
            wielomian[i] /= res;
        }
    }
    WIELOMIAN operator>>(int ile) {
        if (ile > size) {
            WIELOMIAN Q(0 , 0);
            return Q;
        }
        if (ile == 0) {
            WIELOMIAN W(wielomian, size, size);
            return W;
        }
        if (ile < 0) {
            WIELOMIAN Q(0 , 0);
            return Q;
        }
        WIELOMIAN W(wielomian, size, size);
        for (int i = 0; i < ile; i ++) {
            for (int j = 0; j < size - 1; j++) {
                if (ile != 0)
                    W.wielomian[j] = (int)(wielomian[j + 1] / ile) ;
                else W.wielomian[j] = 0;
            }
        }
        W.size -= ile;
        WIELOMIAN M(W.wielomian, W.size, W.size);
        return M;
    }
    WIELOMIAN& operator<<=(int ile) {
        if (ile == 0) {
            return *this;
        }
        if (ile < 0) {
            size = 0;
            wielomian[0] = 0;
            return *this;
        }
        WIELOMIAN W(wielomian, size + ile, size);
        delete[] wielomian;
        wielomian = new int[size + ile];
        for (int i = 0; i < size + ile ; i++) {
            wielomian[i] = 0;
        }
        for (int i = 0; i < size ; i++) {
            wielomian[i + ile] = (int)(W.wielomian[i] * ile);
        }
        size += ile;
        return *this;
    }
    WIELOMIAN& operator>>=(int ile) {
        if (ile > size) {
            size = 0;
            wielomian[0] = 0;
            return *this;
        }
        if (ile == 0) {
            return *this;
        }
        if (ile < 0) {
            size = 0;
            wielomian[0] = 0;
            return *this;
        }
        WIELOMIAN W(wielomian, size, size);
        delete[] wielomian;
        wielomian = new int[size - ile];
        for (int i = 0; i < size - ile ; i++) {
            wielomian[i] = 0;
        }
        for (int i = 0; i < ile; i ++) {
            for (int j = 0; j < size - 1; j++) {
                if(ile != 0)
                    wielomian[j] = (int)(W.wielomian[j + 1] / ile) ;
                else wielomian[j] = 0;
            }
        }
        size -= ile;
        return *this;
    }
    WIELOMIAN operator+=(const WIELOMIAN wiel) {

        if (this->size >= wiel.size) {
            for (int i = 0;i < wiel.size; i++) {
                this->wielomian[i] += wiel.wielomian[i];
            }
        } else {
            WIELOMIAN W;
            delete[] W.wielomian;
            W.wielomian = new int[this->size];
            W.size = this->size;
            for (int i = 0; i < size; i++) {
                W.wielomian[i] = this->wielomian[i];
            }
            delete[] wielomian;
            wielomian = new int[wiel.size];
            for (int i = 0; i < size; i++)
                this->wielomian[i] = W.wielomian[i];
            for (int i = size; i < wiel.size; i++) {
                wielomian[i] = 0;
            }
                this->size = wiel.size;
            for (int i = 0;i < wiel.size; i++) {
                wielomian[i] += wiel.wielomian[i];
            }
        }
        while(size - 1 >= 0 && wielomian[size - 1] == 0) size--;
        int value = NWD(wielomian, size);
        for (int i = 0; i < size; i++) wielomian[i] /= value;

        return *this;
    }
    WIELOMIAN& operator-=(WIELOMIAN wiel) {
        if (this->size >= wiel.size) {
            for (int i = 0;i < wiel.size; i++) {
                this->wielomian[i] -= wiel.wielomian[i];
            }
        } else {
            WIELOMIAN W;
            delete[] W.wielomian;
            W.wielomian = new int[this->size];
            W.size = this->size;
            for (int i = 0; i < size; i++) {
                W.wielomian[i] = this->wielomian[i];
            }
            delete[] wielomian;
            wielomian = new int[wiel.size];
            for (int i = 0; i < size; i++)
                this->wielomian[i] = W.wielomian[i];
            for (int i = size; i < wiel.size; i++) {
                wielomian[i] = 0;
            }
                this->size = wiel.size;
            for (int i = 0;i < wiel.size; i++) {
                wielomian[i] -= wiel.wielomian[i];
            }
        }
        while(size - 1 >= 0 && wielomian[size - 1] == 0) size--;
        int value = NWD(wielomian, size);
        for (int i = 0; i < size; i++) wielomian[i] /= value;

        return *this;
    }
    WIELOMIAN& operator*=(WIELOMIAN wiel) {
        WIELOMIAN W(wielomian, size + wiel.size - 1, size);
        for (int i = 0; i < size + wiel.size - 1; i++) {
            W.wielomian[i] = 0;
        }
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < wiel.size; j++) {
                W.wielomian[i + j] += wiel.wielomian[j] * wielomian[i];
            }
        }
        delete[] wielomian;
        wielomian = new int[W.size];
        for (int i = 0; i < W.size; i++) {
            wielomian[i] = W.wielomian[i];
        }
        while(size - 1 >= 0 && wielomian[size - 1] == 0) size--;
        int value = NWD(wielomian, size);
        for (int i = 0; i < size; i++) wielomian[i] /= value;
        return *this;
    }
    WIELOMIAN& operator/=(WIELOMIAN wiel) {
        if (size - wiel.size + 1 <= 0) {
            size = 1;
            wielomian[0] = 0;
            return *this;
        }

        //------------------
        int licznikThis[size];
        int mianownikThis[size];

        int licznikWiel[wiel.size];
        int mianownikWiel[wiel.size];

        for (int i = 0; i < size; i++) {
            licznikThis[i] = wielomian[i];
            mianownikThis[i] = 1;
        }
        if (size - wiel.size + 1 <= 0)
            return *this;
        int divide, rightN, divideN;

        WIELOMIAN left(this->wielomian, this->size, "a");
        WIELOMIAN right(wiel.wielomian, wiel.size, "a");
        int newSize = left.size - right.size + 1;
        int *zer = new int[newSize];
        for (int i = 0; i < newSize; ++i) zer[i] = 1;

        WIELOMIAN result(zer, newSize, "a");

        int* rightDiv = new int[right.size];
        int* leftDiv = new int[left.size];
        for(int i = 0; i < left.size; i++) leftDiv[i] = 1;
        int* resultDiv = new int[result.size];
        for(int i = 0; i < result.size; i++) resultDiv[i] = 1;
        int n = newSize - 1;
        int sizeLeft = left.size - 1;
        int sizeRight = right.size - 1;
        //------------------


        while(n >= 0) {
            newSize--;
            right = wiel;
            for(int i = 0; i < right.size; i++) rightDiv[i] = 1;

            rightN = left.wielomian[left.size - 1];
            divideN = right.wielomian[right.size - 1] * leftDiv[left.size - 1];
            divide = nwd(rightN, divideN);
            rightN /= divide;
            divideN /= divide;
            result.wielomian[newSize] = rightN;
            resultDiv[newSize] = divideN;

            for (int i = 0; i < right.size; i++) {

                right.wielomian[i] *= rightN;
                rightDiv[i] *= divideN;
                for (int k = 0 ;k < left.size; k++);
                divide = nwd(right.wielomian[i], rightDiv[i]);
                right.wielomian[i] /= divide;
                rightDiv[i] /= divide;
            }

            for (int i = 0; i < right.size; i++) {

                rightN = leftDiv[left.size - 1 - i];
                divideN = rightDiv[right.size - 1 - i];
                right.wielomian[right.size - 1 - i] *= rightN;
                rightDiv[right.size - 1 - i] *= rightN;
                left.wielomian[left.size - 1 - i] *= divideN;
                leftDiv[left.size - 1 - i] *= divideN;

                left.wielomian[left.size - 1 - i] -= right.wielomian[right.size - 1 - i];
                divide = nwd(left.wielomian[left.size - 1 - i], leftDiv[left.size - 1 - i]);
                left.wielomian[left.size - 1 - i] = left.wielomian[left.size - 1 - i] / divide;
                leftDiv[left.size - 1 - i] = leftDiv[left.size - 1 - i] / divide;

            }
            left.size--;
            n--;
        }

        int mianownik = resultDiv[0];
        if(mianownik < 0) mianownik = -mianownik;
        for(int i = 1; i < result.size; i++) {
            int a = resultDiv[i];
            if(a < 0) a = -a;

            if(a > mianownik) {
                mianownik = a;
            }
        }

        for(int i = 0; i < result.size; i++) {
            resultDiv[i] = mianownik / resultDiv[i];
            result.wielomian[i] *= resultDiv[i];
        }

        result.shortW();
        *this = result;
        return *this;
    }

    WIELOMIAN operator%=(WIELOMIAN wiel) {
        //------------------
        if (size - wiel.size + 1 <= 0)
            return *this;

        int licznikThis[size];
        int mianownikThis[size];

        int licznikWiel[wiel.size];
        int mianownikWiel[wiel.size];

        for (int i = 0; i < size; i++) {
            licznikThis[i] = wielomian[i];
            mianownikThis[i] = 1;
        }
        int divide, rightN, divideN;

        WIELOMIAN left(this->wielomian, this->size, "a");
        WIELOMIAN right(wiel.wielomian, wiel.size, "a");
        int newSize = left.size - right.size + 1;
        int *zer = new int[newSize];
        for (int i = 0; i < newSize; ++i) zer[i] = 1;

        WIELOMIAN result(zer, newSize, "a");

        int* rightDiv = new int[right.size];
        int* leftDiv = new int[left.size];
        for (int k = 0 ;k < left.size; k++);
        for(int i = 0; i < left.size; i++) leftDiv[i] = 1;
        int* resultDiv = new int[result.size];
        for(int i = 0; i < result.size; i++) resultDiv[i] = 1;
        int n = newSize - 1;
        int sizeLeft = left.size - 1;
        int sizeRight = right.size - 1;
        //------------------


        while(n >= 0) {
            newSize--;
            right = wiel;
            for(int i = 0; i < sizeRight + 1; i++) rightDiv[i] = 1;

            rightN = left.wielomian[left.size - 1];
            divideN = right.wielomian[sizeRight] * leftDiv[left.size - 1];
            divide = nwd(rightN, divideN);
            rightN /= divide;
            divideN /= divide;
            result.wielomian[newSize] = rightN;
            resultDiv[newSize] = divideN;

            for (int i = 0; i < sizeRight + 1; i++) {

                right.wielomian[i] *= rightN;
                rightDiv[i] *= divideN;
                divide = nwd(right.wielomian[i], rightDiv[i]);
                right.wielomian[i] /= divide;
                rightDiv[i] /= divide;
            }

            for (int i = 0; i < sizeRight + 1; i++) {

                rightN = leftDiv[left.size - 1 - i];
                divideN = rightDiv[sizeRight - i];
                right.wielomian[sizeRight - i] *= rightN;
                rightDiv[sizeRight - i] *= rightN;
                left.wielomian[left.size - 1 - i] *= divideN;
                leftDiv[left.size - 1 - i] *= divideN;

                left.wielomian[left.size - 1 - i] -= right.wielomian[sizeRight - i];
                divide = nwd(left.wielomian[left.size - 1 - i], leftDiv[left.size - 1 - i]);
                left.wielomian[left.size - 1 - i] = left.wielomian[left.size - 1 - i] / divide;
                leftDiv[left.size - 1 - i] = leftDiv[left.size - 1 - i] / divide;

            }
            left.size--;
            n--;
        }

        int mianownik = leftDiv[0];
        if(mianownik < 0) mianownik = -mianownik;
        for(int i = 1; i < left.size; i++) {
            int a = leftDiv[i];
            if(a < 0) a = -a;

            if(a > mianownik) {
                mianownik = a;
            }
        }
        for(int i = 0; i < left.size; i++) {
            leftDiv[i] = mianownik / leftDiv[i];
            left.wielomian[i] *= leftDiv[i];
        }
        WIELOMIAN W(left.wielomian, this->size, "");
        *this = W;
        return *this;
    }
    WIELOMIAN operator++ () {
        for (int i = 0; i < size; i++) {
            wielomian[i]++;
        }
        while(size - 1 >= 0 && wielomian[size - 1] == 0) size--;
            int value = NWD(wielomian, size);
            for (int i = 0; i < size; i++) wielomian[i] /= value;
        WIELOMIAN W(wielomian, size, size);
        return W;
    }
    WIELOMIAN operator++ (int) {
        WIELOMIAN W(wielomian, size, size);
        for (int i = 0; i < size; i++) {
            wielomian[i]++;
        }
        while(size - 1 >= 0 && wielomian[size - 1] == 0) size--;
            int value = NWD(wielomian, size);
            for (int i = 0; i < size; i++) wielomian[i] /= value;
        return W;
    }
    WIELOMIAN operator-- () {
        for (int i = 0; i < size; i++) {
            wielomian[i]--;
        }
        while(size - 1 >= 0 && wielomian[size - 1] == 0) size--;
            int value = NWD(wielomian, size);
            for (int i = 0; i < size; i++) wielomian[i] /= value;
        WIELOMIAN W(wielomian, size, size);
        return W;
    }
    WIELOMIAN operator-- (int) {
        WIELOMIAN W(wielomian, size, size);
        for (int i = 0; i < size; i++) {
            wielomian[i]--;
        }
        while(size - 1 >= 0 && wielomian[size - 1] == 0) size--;
            int value = NWD(wielomian, size);
            for (int i = 0; i < size; i++) wielomian[i] /= value;
        return W;
    }
    void* operator new(size_t sz) {
        przeladowanych++;
        return ::operator new(sz);
    }

    void operator delete(void* p) {
        przeladowanych--;
        ::operator delete(p);
    }
    int size;
    int* wielomian;
    static int przeladowanych;
};
    ostream& operator<<(ostream& os, WIELOMIAN wiel) {
        os << "( ";
        for (int i = 0; i < wiel.size - 1; i++) {
            os << wiel.wielomian[i] << ", ";
        }
        if(wiel.size - 1 >= 0)
            os << wiel.wielomian[wiel.size - 1] << " )";
        else
            os << wiel.wielomian[wiel.size] << " )";
        return os;
    }
    istream& operator>>(istream& is, WIELOMIAN& wiel) {
        int size;
        is >> size;
        wiel.size = size + 1;
        wiel.wielomian = new int[wiel.size + 1];
        for (int i = 0; i < wiel.size; i++) is >> wiel.wielomian[i];

        int value = NWD(wiel.wielomian, wiel.size);

        for (int i = 0; i < wiel.size; i++) wiel.wielomian[i] /= value;
        return is;
    }
    bool operator==(WIELOMIAN left, WIELOMIAN right) {
        if (left.size == right.size) {
            for (int i = left.size - 1; i >= 0; i--) {
                if (left.wielomian[i] != right.wielomian[i]) return false;
            }
        } else {
            return false;
        }
        return true;
    }
    bool operator>=(WIELOMIAN left, WIELOMIAN right) {
        if (left.size > right.size) return true;
        if (left.size == right.size) {
            for (int i = left.size - 1; i >= 0; i--) {
                if (left.wielomian[i] < right.wielomian[i]) return false;
            }
        } else {
            return false;
        }
        return true;
    }
    bool operator<=(WIELOMIAN left, WIELOMIAN right) {
        if (left.size < right.size) return true;
        if (left.size == right.size) {
            for (int i = left.size - 1; i >= 0; i--) {
                if (left.wielomian[i] > right.wielomian[i]) return false;
            }
        } else {
            return false;
        }
        return true;
    }
    bool operator<(WIELOMIAN left, WIELOMIAN right) {
        if (left.size < right.size) return true;
        else if (left.size == right.size) {
            for (int i = left.size - 1; i >= 0; i--) {
                if (left.wielomian[i] > right.wielomian[i]) return false;
            }
            if (left == right) return false;
        } else {
            return false;
        }
        return true;
    }
    bool operator>(WIELOMIAN left, WIELOMIAN right) {
        if (left.size > right.size) return true;
        else if (left.size == right.size) {
            for (int i = left.size - 1; i >= 0; i--) {
                if (left.wielomian[i] < right.wielomian[i]) return false;
            }
            if (left == right) return false;
        } else {
            return false;
        }
        return true;
    }
    bool operator!=(WIELOMIAN left, WIELOMIAN right) {
        if(left == right) return false;
        else return true;
    }

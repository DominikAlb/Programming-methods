//Dominik Albiniak - 4
import java.util.Scanner;
public class Source {
public static void main (String args[]) {
  Scanner in = new Scanner (System.in);
  int N, n1,n2, q;

  q = in.nextShort();
  while ( q > 0) {
  n1 = in.nextShort();
  n2 = in.nextShort();
  if(n1>0 && n2>0){
  int[][] B = new int[n1][n2];
  for (int i =0 ; i<n1;  i++)
    for (int j=0;j<n2;j++)
      B[i][j] = in.nextShort();
  int wp, kp ,wk ,kk ;
  int swp=0,skp=0,swk=0,skk =0;
  wp = kp = wk = kk = 0;
  boolean lz = true;//do samych zer
  int sssssss =0 ;
  boolean ld = false;// ld- czy jest liczba dodatnia
  boolean close = false;// jak znajdzie tylko jedno zero, to innych nie przyjmuje
  int[] A = new int[n2];       // tablica pomocnicza 1-wymiarowa
  int maxi= 0, suma, kol1, kol2, kol3, kol4;   // będzie szukać największej sumy z tablicy A,
  kol1=kol2=kol3=kol4=0;
                                  // zwróci zakres od indeksu kol1 do kol2
   for (int ip=0; ip<n1; ip++)
  {
      for (int k=0; k<n2; k++) A[k]=0;          // zerowanie tablicy pomocniczej
      for (int ik=ip; ik<n1; ik++)
      {
        for (int k=0; k<n2; k++) {A[k] += B[ik][k];
        }     // Ak jest sumą w kolumnie k od wiersza ip do wiersza ik

        //Tu sie sprawdza tylko K D1 R^1

          int maxi3,curr;//curr - suma na teraz, maxi3 - maksymalna suma;
          kol1=kol2=kol3=kol4=0;
          maxi3 = 0;
          curr = 0;

          for (int ix=0; ix < n2; ix++){
            curr = (curr + A[ix]);
            if(curr <= 0) {
              if (curr == 0 && lz && maxi3 == 0) {
                lz = false;
                maxi3 = 0;
                kol2 = kol3 = ix;
                ld = true;
              }
              curr = 0; kol1 = ix + 1;
            } else {
              ld = true;
              kol4 = ix;
              if (curr > maxi3) {
                maxi3 = curr; kol2 = ix; kol3 = kol1;
              } else if (curr == maxi3 && kol2 - kol3 > kol4 - kol1) {
                kol2 = ix; kol3 = kol1;
              }
            }
          }

          suma = maxi3;
          if(kol3>kol2)
            kol2=kol3; //jakby prawy wiersz byl mniejszy od lewego
         // największa suma podtablicy od wiersza  ip do ik jest w kolumnach od kol2 do kol3
          if (suma>maxi) {maxi=suma; wp=ip; kp=kol3; wk=ik; kk=kol2;}
          else if(ld && suma==maxi && (kol2-kol3+1)*(ik-ip+1) < (wk-wp+1)*(kk-kp+1)){
            maxi=suma; wp=ip; kp=kol3; wk=ik; kk=kol2;
          } else if (suma == 0 && (!lz) && maxi == 0 && (ld) && (!close)) {
            wp=ip; kp=kol3; wk=ik; kk=kol2; close = true;
          }
      }
  }

  sssssss = maxi;//najwieksza mozliwa suma
  if(ld) { // jezeli to liczba dodatnia, to...
  System.out.println("max_sum="+sssssss);
  System.out.println("["+wp+".."+ wk +", "+kp+".."+kk+"]");
} else {// Jezeli < 0
System.out.println("0");
}
}else {// jezeli kolumna lub wiersz jest mniejsza od zera
  System.out.println("0");
}
  q--;
}
}
}

// Testy sprawdzjace :
/* 9 9
3 1 0 2 1 5 -7 0 0
2 2 2 0 0 0 0 0 1
-1 3 -1 -5 -4 2 6 -2 4
-1 -5 2 4 5 6 8 10 -20
-1 3 -4 -2 -10 5 0 0 1
-1 4 0 0 0 0 0 0 0
-1 1 1 1 0 -1 -2 4 -5
0 1 2 -3 0 1 2 0 5
0 -2 -4 0 0 1 5 10 0
max_sum=55/*
//[2..8, 5..7]
/*
2 2
-1 1
1 -1
max_sum=1
[0..0, 1..1]
2 3
1 0 1
-1 1 -1
max_sum=2
[0..0, 0..2]
3 10
1 0 0 0 0 0 0 0 0 0
0 0 0 0 0 1 0 0 0 -1
0 0 0 0 0 0 0 0 0 1
max_sum=2
[0..1, 0..5]
3 3
1 3 5
-5 -3 -1
14 0 0
max_sum=14
[2..2, 0..0]
3 3
-1 -1 -1
-2 0 -2
-1 -1 -1
max_sum=0
[1..1, 1..1]
3 3
-1 -1 -1
-2 -1 -2
-2 -1 -2
0
3 3
4 3 -10
-4 -4 -4
1 5 1
max_sum=7
[0..0, 0..1]
3 3
4 3 -10
-4 -4 -4
1 5 2
max_sum=8
[2..2, 0..2]



3 5
-1 -2 -3 -1 -2
3 1 1 4 1
0 0 0 0 0
max_sum=10
[1..1, 0..4]

6 1
0
4
-5
2
2
-2
max_sum=4
[1..1, 0..0]

4 6
3 2 -2 -13 1 -5
0 -1 1 0 6 0
-3 2 1 1 -4 9
20 1 0 -40 0 1
max_sum=24
[0..3, 0..1]

4 4
-14 11 -4 -19
5 -20 -2 10
-1 -1 20 -1
0 0 0 0
max_sum=27
[1..2, 2..3]

2 3
-1 -1 -1
-1 -1 -1
0
2 2
-1 2
1 2
max_sum=4
[0..1, 1..1]
2 3
0 -1 -1
-1 -1 -1
max_sum=0
[0..0, 0..0]
*/

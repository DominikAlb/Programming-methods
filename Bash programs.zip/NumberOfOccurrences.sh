#Dominik Albiniak
#!/bin/bash
read operator
while read string
do
	to=${operator:0:1}
	to2=${operator:0:1}
	to2=${to2^^}
	i=0
	ile=0
	len=${#string}
	if [[ ${operator:1:1} == '=' ]]
	then
	while [ $i -lt $len ]
	 do
	     znak=${string:$i:1}
	     if [[ $znak == $to ]]
		 then
		 ((ile++))
	     fi
	     ((i++))
	 done
	else
	while [ $i -lt $len ]
	 do
	     znak=${string:$i:1}
	     if [[ $znak == $to ]] || [[ $znak == $to2 ]]
		 then
		 ((ile++))
	     fi
	     ((i++))
	 done
	fi
	echo $ile
done
echo ""
#Examples
#a
#Ala ma kota
#Ala ma psa
#Ala ma kanarka
#4
#4
#6
#a=
#Ala ma kota
#Ala ma psa
#Ala ma kanarka
#3
#3
#5

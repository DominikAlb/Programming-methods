//Dominik Albiniak - 4
//QuickSort with memory O(1)
import java.util.Scanner;

public class Source {

    static Scanner in = new Scanner(System.in);
    static int[] tab;
    public static void main(String[] args) {

        int m = in.nextInt();
        while (m > 0) {
            int n = in.nextInt();

            tab = new int [n];
            for (int i = 0; i < n; i++)
               tab[i] = in.nextInt();
                if (n <= 15 ) {
                  SmallinsertionSort();
                } else {
                  QuickSort(0,n - 1, n - 1);
                }
            m--;
            for (int i = 0; i < n; i++) {
              if (tab[i] >= 0) System.out.print(tab[i] + " ");
              else System.out.print(-tab[i] + " ");
            }
            System.out.println();
        }
    }

    static void QuickSort(int left, int right, int length) {
        int i = 0;
        while(left < right || i > 0)
        {
            if(left < right)
            {
                int q = TruePartition(left, right);
                tab[right] = -tab[right];
                right = q - 1;
                i++;
            }
            else
            {
                left = right++ + 2;

                while(right < length)
                    if(tab[right] < 0) {
                        break;
                    }
                    else
                        right++;
                  tab[right] = -tab[right];
                i--;
            }
        }
    }
      public static void SmallinsertionSort(){

              int klucz, j;
              for (int i=1;i<tab.length;i++){
                  j=i;
                  klucz=tab[i];
                  while (j>0 && tab[j-1]>klucz) {
                      tab[j]=tab[j-1];
                      j--;
                  }
                  tab[j]=klucz;
              }
        }
    static void swap(int i, int j) {
        int temp = tab[i];
        tab[i] = tab[j];
        tab[j] = temp;
    }
    static int TruePartition (int left, int right) {
      swap((left+right)/2, right);
      long x = tab[right];
      int i = left - 1, j = right;
      while(true){
        while (tab[++i] < x);
        while (j > left && tab[--j] > x);
        if (i >= j) break;
        else swap(i, j);
      }
      swap(i, right);
      return i;
    }
    static int Partition(int left, int right) {
        long x = tab[right];
        int i = left - 1;

        for(int j = left;j < right; j++) {
            if(tab[j] < x ) {
                swap(++i, j);
            } else if (tab[j] == x) {
              ++i;
            }
        }

        swap(i + 1, right);
        return i + 1;
    }
}
/*    TESTY:
30
5
5 4 3 2 1
1 2 3 4 5
10
1 1 1 1 1 1 1 1 1 1
1 1 1 1 1 1 1 1 1 1
5
5 4 5 4 5
4 4 5 5 5
10
3 3 3 3 4 4 4 4 3 3
3 3 3 3 3 3 4 4 4 4
10
4 5 6 5 4 3 2 7 4 2
2 2 3 4 4 4 5 5 6 7
10
899 3772 263 1787 23839 27382 27832 8283 37281 3213
263 899 1787 3213 3772 8283 23839 27382 27832 37281
10
3 3 3 3 3 3 3 3 3 1
1 3 3 3 3 3 3 3 3 3
1 3 3 3 3 3 3 3 3 3
3
3 3 3
3 3 3
10
10
10
10
10
10
10
10
10
10
10
10 10 10 10 10 10 10 10 10 10
10
1 3 3 3 3 3 3 3 3 3
1 3 3 3 3 3 3 3 3 3
10
1 2 1 1 2 1 1 2 1 1
1 1 1 1 1 1 1 2 2 2
2 1 1 1 1 1 1 1 1 2
1 1
1
1
1
1
10
1 10
10
2 1 1 1 1 1 1 1 1 2
1 1 1 1 1 1 1 1 2 2
10
4 8 5 1 2 6 4 3 5 8
1 2 3 4 4 5 5 6 8 8
10
3 6 2 6 3 1 7 4 32 2
1 2 2 3 3 4 6 6 7 32
10
2 6 3 1 5 7 5 3 2 1
1 1 2 2 3 3 5 5 6 7
10
8 6 4 3 7 4 2 7 4 7
2 3 4 4 4 6 7 7 7 8
10
9 4 77 3 1 6 3 4 5 6
1 3 3 4 4 5 6 6 9 77
10
8 5 43 6 7 3 1 5 5 5
1 3 5 5 5 5 6 7 8 43
10
2 6 8 5 3 2 5 8 8 8
2 2 3 5 5 6 8 8 8 8
10
1 6 4 3 7 9 6 4 8 1
1 1 3 4 4 6 6 7 8 9
10
5 1 7 9 2 4 6 8 4 2
1 2 2 4 4 5 6 7 8 9
10
4 8 7 5 3 1 5 9 7 5
1 3 4 5 5 5 7 7 8 9
10
2 1 5 4 7 9 5 6 2 4
1 2 2 4 4 5 5 6 7 9

1
10
2 5 4 6 4 7 9 8 4 6
2 4 4 4 5 6 6 7 8 9
*/

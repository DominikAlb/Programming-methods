#Dominik Albiniak
#!/bin/bash
read a
while read string
do
    out=${string##*:}
    out=${out:2:150}
    katalog=${string:0:1}
    wykonywalny=${string:3:1}
    if [[ $katalog == 'd' ]]
    then
        napis="$out/ "
    else
        if [[ $wykonywalny == 'x' ]]
        then
            napis="$out* "
        else
            napis="$out "
        fi
    fi
    i=1
    while [ $i -lt 10 ]; do
		suma=0
        char="${string:$i:1}"
		if [ "$char" = "r" ]
        then
			suma=4
		fi
		((i++))
        char="${string:$i:1}"
		if [ "$char" = "w" ]
        then
			suma=$((suma+2))
		fi
		((i++))
        char="${string:$i:1}"
		if [ "$char" = "x" ]
        then
			suma=$((suma+1))
		fi
		napis="$napis$suma"
		((i++))
	done
	echo $napis
done
echo
#total 4
#drwxr----- 2 user1 students 4096 Mar 22 16:37 folder1
#-rwxrwxrwx 1 user1 students    0 Mar 22 16:37 plik1.txt
#-rwxr---wx 1 user1 students    0 Mar 22 16:37 plik2.txt
#-r-xr----- 1 user1 students    0 Mar 22 16:37 plik3.txt
#-rw-r----- 1 user1 students    0 Mar 22 16:39 plik4.txt

#folder1/ 740
#plik1.txt* 777
#plik2.txt* 743
#plik3.txt* 540
#plik4.txt 640
